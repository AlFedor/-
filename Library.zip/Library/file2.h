// MDCA.cpp - реализация библиотеки MDCA
#include "MDCA.h"

MDCA::MDCA(uint8_t lff_pin, uint8_t lfb_pin, uint8_t rff_pin, uint8_t rfb_pin,
           uint8_t lbf_pin, uint8_t lbb_pin, uint8_t rbf_pin, uint8_t rbb_pin,
           uint8_t ik_pin) :
  _lff(lff_pin), _lfb(lfb_pin), _rff(rff_pin), _rfb(rfb_pin),
  _lbf(lbf_pin), _lbb(lbb_pin), _rbf(rbf_pin), _rbb(rbb_pin),
  _ik(ik_pin) {}

void MDCA::begin() {
  pinMode(_lff, OUTPUT);
  pinMode(_lfb, OUTPUT);
  pinMode(_rff, OUTPUT);
  pinMode(_rfb, OUTPUT);
  pinMode(_lbf, OUTPUT);
  pinMode(_lbb, OUTPUT);
  pinMode(_rbf, OUTPUT);
  pinMode(_rbb, OUTPUT);
  pinMode(_ik, INPUT);
}

void MDCA::go(int rf, int lf, int rb, int lb) {
  // Управление левым передним мотором
  if (lf < 0) {
    analogWrite(_lff, abs(lf));
    analogWrite(_lfb, 0);
  } else {
    analogWrite(_lff, 0);
    analogWrite(_lfb, abs(lf));
  }

  // Управление правым передним мотором
  if (rf < 0) {
    analogWrite(_rff, abs(rf));
    analogWrite(_rfb, 0);
  } else {
    analogWrite(_rff, 0);
    analogWrite(_rfb, abs(rf));
  }

  // Управление левым задним мотором
  if (lb < 0) {
    analogWrite(_lbf, abs(lb));
    analogWrite(_lbb, 0);
  } else {
    analogWrite(_lbf, 0);
    analogWrite(_lbb, abs(lb));
  }

  // Управление правым задним мотором
  if (rb < 0) {
    analogWrite(_rbf, abs(rb));
    analogWrite(_rbb, 0);
  } else {
    analogWrite(_rbf, 0);
    analogWrite(_rbb, abs(rb));
  }
}

int MDCA::dist_ik() {
  return 32 * pow(analogRead(_ik) * 5.0 / 1024.0, -1.1);
}

void MDCA::stopp(long t) {
  long t0 = millis();
  
  while(millis() < t0 + t) {
    go(255, 255, 255, 255);
    delay(5);
    go(-255, -255, -255, -255);
    delay(5);
  }
  go(0, 0, 0, 0);
}