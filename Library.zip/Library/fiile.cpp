// MDCA.h - Motor and Distance Control for Arduino library
#ifndef MDCA_h
#define MDCA_h

#include <Arduino.h>

class MDCA {
  public:
    // Конструктор с настройкой пинов
    MDCA(uint8_t lff_pin, uint8_t lfb_pin, uint8_t rff_pin, uint8_t rfb_pin,
         uint8_t lbf_pin, uint8_t lbb_pin, uint8_t rbf_pin, uint8_t rbb_pin,
         uint8_t ik_pin);
    
    // Инициализация пинов
    void begin();
    
    // Управление моторами
    void go(int rf, int lf, int rb, int lb);
    
    // Резкая остановка с торможением
    void stopp(long t = 100);
    
    // Измерение расстояния ИК-датчиком
    int dist_ik();
    
  private:
    // Пины для управления моторами
    uint8_t _lff, _lfb, _rff, _rfb, _lbf, _lbb, _rbf, _rbb;
    
    // Пин ИК-датчика
    uint8_t _ik;
};

#endif